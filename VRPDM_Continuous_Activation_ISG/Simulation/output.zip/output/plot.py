# -*- coding: utf-8 -*-
"""
Created on Sun Jan  4 20:10:02 2026

@author: pdalc
"""

import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv("NODEFECT_noPKRapop_DeathProb0.033_IFNsec4.550_VirSec316.667_EndoP0.100_MOI0.0012_IFNbase0.000__av.txt",
                 sep="\t")

# --- Plot 1: totIFNc with shaded error ---
plt.figure(figsize=(8,5))
plt.plot(df["time"], df["totIFNc"], color="blue", label="totIFNc")
plt.fill_between(df["time"],
                 df["totIFNc"] - df["totIFNc_SE"],
                 df["totIFNc"] + df["totIFNc_SE"],
                 color="blue", alpha=0.3)
plt.xlabel("Time")
plt.ylabel("totIFNc")
plt.title("totIFNc with Shaded Error")
plt.legend()
plt.tight_layout()
plt.show()

# --- Plot 2: totVirus with shaded error ---
plt.figure(figsize=(8,5))
plt.plot(df["time"], df["totVirus"], color="red", label="totVirus")
plt.fill_between(df["time"],
                 df["totVirus"] - df["totVirus_SE"],
                 df["totVirus"] + df["totVirus_SE"],
                 color="red", alpha=0.3)
plt.xlabel("Time")
plt.ylabel("totVirus")
plt.title("totVirus with Shaded Error")
plt.legend()
plt.tight_layout()
plt.show()
