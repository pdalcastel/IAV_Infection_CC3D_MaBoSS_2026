import os
import numpy as np
import glob

# Find all files matching the pattern dataX.txt  
fname = "10hRCdeg_1hImport_2hProtUp_3hRepTime_100IFNsec_withPKRapop_"
file_pattern = f"{fname}*.txt"
files = glob.glob(file_pattern)

# Ensure there are files to process
if not files:
    print("No valid data files found.")
    exit()

# Read the header from the first file
with open(files[0], "r") as f:
    header = f.readline().strip()  # Read the first line as the header

# Read all files while skipping headers
data_arrays = []
for file in files:
    try:
        data = np.loadtxt(file, skiprows=1)  # Skip header
        data_arrays.append(data)
    except Exception as e:
        print(f"Error reading {file}: {e}")

# Convert list to NumPy array (Shape: num_files x num_rows x num_cols)
data_stack = np.stack(data_arrays, axis=0)

# Compute mean and standard error
mean_values = np.mean(data_stack, axis=0)
std_error = np.std(data_stack, axis=0, ddof=1) / np.sqrt(len(files))

# Combine mean and standard error side by side
interleaved_data = np.empty((mean_values.shape[0], mean_values.shape[1] * 2))
interleaved_header = []

original_columns = header.split()

for i, col in enumerate(original_columns):
    interleaved_data[:, 2*i] = mean_values[:, i]
    interleaved_data[:, 2*i + 1] = std_error[:, i]
    interleaved_header.extend([col, col + "_SE"])

# Save the results to "result.txt" with the updated header
np.savetxt(f"{fname}_av.txt", interleaved_data, fmt="%.6f", delimiter="\t", header="\t".join(interleaved_header), comments='')

print("Results saved to result.txt")
